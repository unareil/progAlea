# progAlea
Program assign a random person
